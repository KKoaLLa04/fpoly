/* zahl.d.ts (C) 2022-present SheetJS */
// TypeScript Version: 2.2
declare const XLSX_ZAHL_PAYLOAD: string;
export default XLSX_ZAHL_PAYLOAD;
